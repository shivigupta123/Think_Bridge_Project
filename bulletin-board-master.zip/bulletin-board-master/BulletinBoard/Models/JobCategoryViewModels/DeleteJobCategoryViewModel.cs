﻿namespace BulletinBoard.Models.JobCategoryViewModels
{
    public class DeleteJobCategoryViewModel
    {
        public string JobCategoryId { get; set; }
        
        public string Name { get; set; }
    }
}
