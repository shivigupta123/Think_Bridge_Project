﻿namespace BulletinBoard.Models.JobCategoryViewModels
{
    public class DetailsJobCategoryViewModel
    {
        public string JobCategoryId { get; set; }
        
        public string Name { get; set; }
    }
}
