﻿namespace BulletinBoard.Models.JobTypeViewModels
{
    public class DeleteJobTypeViewModel
    {
        public string JobTypeId { get; set; }
        
        public string Name { get; set; }
    }
}
