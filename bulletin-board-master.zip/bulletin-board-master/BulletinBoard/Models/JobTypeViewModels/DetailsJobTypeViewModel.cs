﻿namespace BulletinBoard.Models.JobTypeViewModels
{
    public class DetailsJobTypeViewModel
    {
        public string JobTypeId { get; set; }
        
        public string Name { get; set; }
    }
}
