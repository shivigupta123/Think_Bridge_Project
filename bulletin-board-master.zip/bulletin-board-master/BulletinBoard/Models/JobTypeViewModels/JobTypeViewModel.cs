﻿namespace BulletinBoard.Models.JobTypeViewModels
{
    public class JobTypeViewModel
    {
        public string JobTypeId { get; set; }
        
        public string Name { get; set; }
    }
}
