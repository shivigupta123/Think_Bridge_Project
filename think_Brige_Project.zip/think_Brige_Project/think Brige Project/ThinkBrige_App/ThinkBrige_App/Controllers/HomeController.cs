﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Thinkbridge_Service;
using Thinkbridge_Service.Model;


namespace ThinkBrige_App.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        private ProductService ProductListBind; 
        public HomeController()
        {
            ProductListBind = new ProductService();

        }
        public ActionResult Index()
        {
            return View();
        }
        
        public ActionResult Product()
        {
            List<ProductBAL> List = new List<ProductBAL>();
            return View(List);
        }

        public PartialViewResult Productlist()
        {
            List<ProductBAL> List = new List<ProductBAL>();
            List = ProductListBind.GetProduct();
            return PartialView(List);
        }
        

        public ActionResult AddProduct()
        {
            ModelState.Clear();
            return View();
        }
        [HttpGet]
        public ActionResult EditProduct(int Id)
        {
            var Model=ProductListBind.GetProduct(Id).FirstOrDefault();
            return View("AddProduct",Model);
        }

        public ActionResult Delete(int id)
        {
            var Model = ProductListBind.DeleteProduct(id);
            return RedirectToAction("Product");
        }
        [HttpPost]
        public ActionResult AddProduct(ProductBAL model)
        {
            if (model.Product_Name != null && model.Product_Price > 0)
            {
                var ResultData = ProductListBind.ADDProduct(model.ProductId, model.UserId, model.Product_Name, model.Product_Desc, model.Product_Price, model.Product_Type, model.Product_Cat);
                if (ResultData > 0)
                {
                    return RedirectToAction("Product", "Home");
                }

                else
                {
                    ModelState.AddModelError("message", "Please fill required field");
                }
            }
            return View("AddProduct", model);
        }
    }
}