﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThinkBrige_App.Models;

namespace ThinkBrige_App.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        public PartialViewResult Login()
        {
            return PartialView();
        }
        [HttpPost]
        public ActionResult Signin(Loginviewmodel mode)
        {
            if (ModelState.IsValid)
            {
                if(mode.LoginId.ToLower()=="admin@gmail.com".ToLower() && mode.Password == "123456")
                {
                    return RedirectToAction("index","Home");
                }
                else
                {
                   // ViewBag.message = "username and password incorrect";
                    ModelState.AddModelError("Mesaager", "username and password incorrect");
                }
            }
            else
            {
               // ViewBag.message = "username and password incorrect";
                ModelState.AddModelError("Mesaager", "username and password incorrect");

            }
            return View("Index", mode);
        }
    }
}