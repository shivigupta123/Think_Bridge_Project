﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thinkbridge_DAL;
using Thinkbridge_Service.Model;

namespace Thinkbridge_Service
{
    public class MasterService
    {
        private ThinkBridgeDBEntities db;
        public MasterService()
        {
            db = new ThinkBridgeDBEntities();
        }

        public List<UserBAL> Getuser()
        {
            List<UserBAL> List = new List<UserBAL>();
            try
            {
                string query = "usp_User '','','','','','','select'";
                List = db.Database.SqlQuery<UserBAL>(query).ToList();
            }
            catch (Exception )
            {

                
            }
            return List;
        }
        public List<UserBAL> ADDuser(int usrid,string fname,string lname,string password,string Email)
        {
            List<UserBAL> List = new List<UserBAL>();
            try
            {
                string query = "usp_User "+ usrid + ",'"+ fname + "','"+ lname + "','"+ password + "','"+ Email + "','','insert'";
                List = db.Database.SqlQuery<UserBAL>(query).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return List;
        }
    }
}
