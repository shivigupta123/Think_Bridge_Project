﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thinkbridge_Service.Model
{
    public class ProductBAL
    {
       
        public int ProductId { get; set; }
        public int UserId { get; set; }        
        public string Product_Name { get; set; }
        [Required]
        public string Product_Desc { get; set; }
        [Required]
        public int Product_Price { get; set; }
        [Required]
        public string Product_Type { get; set; }
        [Required]
        public string Product_Cat { get; set; }
      
    }
}
