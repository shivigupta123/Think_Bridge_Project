﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thinkbridge_DAL;
using Thinkbridge_Service.Model;

namespace Thinkbridge_Service
{
    public class ProductService
    {
        private ThinkBridgeDBEntities db;
        public ProductService()
        {
            db = new ThinkBridgeDBEntities();
        }

        public List<ProductBAL> GetProduct()
        {
            List<ProductBAL> List = new List<ProductBAL>();
            try
            {
                string query = "usp_Product '','','','','','','','select',0";
                List = db.Database.SqlQuery<ProductBAL>(query).ToList();
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);

            }
            return List;
        }

        public List<ProductBAL> GetProduct(int Id)
        {
            List<ProductBAL> List = new List<ProductBAL>();
            try
            {
                string query = "GetProductBy_id  "+ Id + "";
                List = db.Database.SqlQuery<ProductBAL>(query).ToList();
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);

            }
            return List;
        }
        public int ADDProduct(int ProductId,int UserId, string Product_Name, string Product_Desc, int Product_Price, string Product_Type, string Product_Cat)
        {
            List<ProductBAL> List = new List<ProductBAL>();
            int Data = 0;
            try
            {
                string query = "usp_Product " + ProductId + ",'" + UserId + "','" + Product_Name + "','" + Product_Desc + "','" + Product_Price + "','" + Product_Type + "','" + Product_Cat + "','insert'";
                //List = db.Database.SqlQuery<ProductBAL>(query).ToList();

                var Prodid = new SqlParameter("@ProductId", SqlDbType.BigInt);
                Prodid.Value = ProductId;

                var Userid = new SqlParameter("@UserId", SqlDbType.BigInt);
                Userid.Value = UserId;

                var ProName = new SqlParameter("@Product_Name", SqlDbType.NVarChar);
                ProName.Value = Product_Name;

                var ProDesc = new SqlParameter("@Product_Desc", SqlDbType.NVarChar);
                ProDesc.Value = Product_Desc;

                var ProPrice = new SqlParameter("@Product_Price", SqlDbType.Int);
                ProPrice.Value = Product_Price;

                var ProType = new SqlParameter("@Product_Type", SqlDbType.NVarChar);
                ProType.Value = Product_Type;

                var Procat = new SqlParameter("@Product_Cat", SqlDbType.NVarChar);
                Procat.Value = Product_Cat;

                var ActionPro = new SqlParameter("@action", SqlDbType.NVarChar);
                ActionPro.Value = "insert";

                var Returnval = new SqlParameter("@Resultval", SqlDbType.Int);
                Returnval.Value = 0;
                Returnval.Direction = ParameterDirection.Output;

                this.db.Database.ExecuteSqlCommand("exec AddProduct @UserId,@ProductId,@Product_Name,@Product_Desc,@Product_Price,@Product_Type,@Product_Cat,@action, @Resultval output",
                                                    Userid, Prodid, ProName, ProDesc, ProPrice, ProType, Procat, ActionPro, Returnval);
                 
                Data = Convert.ToInt32(Returnval.Value);
                return Data;
               // Data = 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Data = 0;
            }
            return Data;
        }
        public int DeleteProduct(int Id )
        {
            int Data = 0;
            var Procat = new SqlParameter("@ProductId", SqlDbType.NVarChar);
            Procat.Value = Id;

            var Returnval = new SqlParameter("@Resultval", SqlDbType.Int);
            Returnval.Value = 0;
            Returnval.Direction = ParameterDirection.Output;

            this.db.Database.ExecuteSqlCommand("exec DeleteProc @ProductId, @Resultval output",
                                                Procat, Returnval);
            Data = Convert.ToInt32(Returnval.Value);
            return Data;
        }
    }

 }

